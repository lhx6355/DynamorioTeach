[drcov](http://dynamorio.org/docs/page_drcov.html) is a DynamoRIO client tool that
collects code coverage information.

[drcachesim](http://dynamorio.org/docs/page_drcachesim.html) is a DynamoRIO client
tool that gathers memory reference information from multiple processes
simultaneously and feeds it to an online cache simulator.

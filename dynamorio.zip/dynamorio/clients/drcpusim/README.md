[drcpusim](http://dynamorio.org/docs/page_drcpusim.html) is a DynamoRIO
client tool that emulates execution on a specified CPU model in order to
validate that a target application does not execute any instructions that
are illegal or not implemented on a legacy processor.

This directory contains fully implemented DynamoRIO clients. See the readme for
each client for more details and a link to public documentation.

This directory contains
[sample DynamoRIO clients](http://dynamorio.org/docs/API_samples.html),
which can be directly
used for analysis or extended with additional functionality. Details about
each client can be found in the source code comments at the top of each file.

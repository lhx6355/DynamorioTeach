This directory contains the doxygen source for the DynamoRIO public API
and usage documentation, found at
[dynamorio.org](http://dynamorio.org/docs/index.html)

This directory contains the core implementation of DynamoRIO. Documentation for
client developers can be found in the [public API](http://dynamorio.org/docs/index.html),
where interface and data structures are found in the *Files* and *Data Structures* tabs,
respectively.
